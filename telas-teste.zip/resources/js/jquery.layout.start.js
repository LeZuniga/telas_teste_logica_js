	var myLayout;
	$(document).ready(function () {
		myLayout = $('body').layout({
			west__showOverflowOnHover: true
		,	west__fxSettings_open: { easing: "easeOutBounce", duration: 750 }
		});
 	});